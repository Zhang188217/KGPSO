# -*- coding: utf-8 -*-

r"""
A Global-best Particle Swarm Optimization (gbest PSO) algorithm.

It takes a set of candidate solutions, and tries to find the best
solution using a position-velocity update method. Uses a
star-topology where each particle is attracted to the best
performing particle.

The position update can be defined as:

.. math::

   x_{i}(t+1) = x_{i}(t) + v_{i}(t+1)

Where the position at the current timestep :math:`t` is updated using
the computed velocity at :math:`t+1`. Furthermore, the velocity update
is defined as:

.. math::

   v_{ij}(t + 1) = w * v_{ij}(t) + c_{1}r_{1j}(t)[y_{ij}(t) − x_{ij}(t)]
                   + c_{2}r_{2j}(t)[\hat{y}_{j}(t) − x_{ij}(t)]

Here, :math:`c1` and :math:`c2` are the cognitive and social parameters
respectively. They control the particle's behavior given two choices: (1) to
follow its *personal best* or (2) follow the swarm's *global best* position.
Overall, this dictates if the swarm is explorative or exploitative in nature.
In addition, a parameter :math:`w` controls the inertia of the swarm's
movement.

An example usage is as follows:

.. code-block:: python

    import pyswarms as ps
    from pyswarms.utils.functions import single_obj as fx

    # Set-up hyperparameters
    options = {'c1': 0.5, 'c2': 0.3, 'w':0.9}

    # Call instance of GlobalBestPSO
    optimizer = ps.single.GlobalBestPSO(n_particles=10, dimensions=2,
                                        options=options)

    # Perform optimization
    stats = optimizer.optimize(fx.sphere, iters=100)

This algorithm was adapted from the earlier works of J. Kennedy and
R.C. Eberhart in Particle Swarm Optimization [IJCNN1995]_.

.. [IJCNN1995] J. Kennedy and R.C. Eberhart, "Particle Swarm Optimization,"
    Proceedings of the IEEE International Joint Conference on Neural
    Networks, 1995, pp. 1942-1948.
"""

# Import standard library
import logging

# Import modules
import math
import random
import torch
import cmath
import numpy as np
import multiprocessing as mp
import heapq
import sklearn.cluster as sc
import sklearn.metrics as sm
from operator import itemgetter, attrgetter
from ..backend.operators import compute_pbest, compute_objective_function
from ..backend.topology import Star
from ..backend.handlers import BoundaryHandler, VelocityHandler
from ..base import SwarmOptimizer
from ..utils.reporter import Reporter
from ..utils.functions import single_obj as fx
from cec2017.functions import f1
from cec2017.functions import f2
from cec2017.functions import f3
from cec2017.functions import f4
from cec2017.functions import f5
from cec2017.functions import f6
from cec2017.functions import f7
from cec2017.functions import f8
from cec2017.functions import f9
from cec2017.functions import f10
from cec2017.functions import f11
from cec2017.functions import f12
from cec2017.functions import f13
from cec2017.functions import f14
from cec2017.functions import f15
from cec2017.functions import f16
from cec2017.functions import f17
from cec2017.functions import f18
from cec2017.functions import f19
from cec2017.functions import f20
from cec2017.functions import f21
from cec2017.functions import f22
from cec2017.functions import f23
from cec2017.functions import f24
from cec2017.functions import f25
from cec2017.functions import f26
from cec2017.functions import f27
from cec2017.functions import f28
from cec2017.functions import f29
from cec2017.functions import f30


import matplotlib.pyplot as plt #导入显示模块

class GlobalBestPSO(SwarmOptimizer):

    def __init__(
        self,
        n_particles,
        dimensions,
        options,
        bounds=None,
        bh_strategy="periodic",
        velocity_clamp=None,
        vh_strategy="unmodified",
        center=1.00,
        ftol=-np.inf,
        init_pos=None,
    ):
        """Initialize the swarm

        Attributes
        ----------
        n_particles : int
            number of particles in the swarm.
        dimensions : int
            number of dimensions in the space.
        options : dict with keys :code:`{'c1', 'c2', 'w'}`
            a dictionary containing the parameters for the specific
            optimization technique.
                * c1 : float
                    cognitive parameter
                * c2 : float
                    social parameter
                * w : float
                    inertia parameter
        bounds : tuple of numpy.ndarray, optional
            a tuple of size 2 where the first entry is the minimum bound while
            the second entry is the maximum bound. Each array must be of shape
            :code:`(dimensions,)`.
        bh_strategy : str
            a strategy for the handling of out-of-bounds particles.
        velocity_clamp : tuple, optional
            a tuple of size 2 where the first entry is the minimum velocity and
            the second entry is the maximum velocity. It sets the limits for
            velocity clamping.
        vh_strategy : str
            a strategy for the handling of the velocity of out-of-bounds particles.
        center : list (default is :code:`None`)
            an array of size :code:`dimensions`
        ftol : float
            relative error in objective_func(best_pos) acceptable for
            convergence. Default is :code:`-np.inf`
        init_pos : numpy.ndarray, optional
            option to explicitly set the particles' initial positions. Set to
            :code:`None` if you wish to generate the particles randomly.
        """
        super(GlobalBestPSO, self).__init__(
            n_particles=n_particles,
            dimensions=dimensions,
            options=options,
            bounds=bounds,
            velocity_clamp=velocity_clamp,
            center=center,
            ftol=ftol,
            init_pos=init_pos,
        )

        # Initialize logger
        self.rep = Reporter(logger=logging.getLogger(__name__))
        # Initialize the resettable attributes
        self.reset()
        # Initialize the topology
        self.top = Star()
        self.bh = BoundaryHandler(strategy=bh_strategy)
        self.vh = VelocityHandler(strategy=vh_strategy)
        self.name = __name__

    def optimize(self, objective_func, iters, n_processes=None, **kwargs):
        """Optimize the swarm for a number of iterations

        Performs the optimization to evaluate the objective
        function :code:`f` for a number of iterations :code:`iter.`

        Parameters
        ----------
        objective_func : callable
            objective function to be evaluated
        iters : int
            number of iterations
        n_processes : int
            number of processes to use for parallel particle evaluation (default: None = no parallelization)
        kwargs : dict
            arguments for the objective function

        Returns
        -------
        tuple
            the global best cost and the global best position.
        """

        self.rep.log("Obj. func. args: {}".format(kwargs), lvl=logging.DEBUG)
        self.rep.log(
            "Optimize for {} iters with {}".format(iters, self.options),
            lvl=logging.INFO,
        )
        # Populate memory of the handlers
        self.bh.memory = self.swarm.position
        self.vh.memory = self.swarm.position
        self.swarm.current_cost=np.zeros(self.swarm.n_particles)
        # Setup Pool of processes for parallel evaluation
        pool = None if n_processes is None else mp.Pool(n_processes)

        self.swarm.pbest_cost = np.full(self.swarm_size[0], np.inf)
        for i in self.rep.pbar(iters, self.name):
            # Compute cost for current position and personal best
            # fmt: off
            # self.swarm.current_cost = compute_objective_function(self.swarm, objective_func, pool=pool, **kwargs)
            for n0 in range(self.swarm.n_particles):
                self.swarm.current_cost[n0]=objective_func(self.swarm.position[n0])

            self.swarm.pbest_pos, self.swarm.pbest_cost = compute_pbest(self.swarm)
            # Set best_cost_yet_found for ftol
            best_cost_yet_found = self.swarm.best_cost
            self.swarm.best_pos, self.swarm.best_cost = self.top.compute_gbest(self.swarm)
            # fmt: on
            self.rep.hook(best_cost=self.swarm.best_cost)
            # Save to history
            hist = self.ToHistory(
                best_cost=self.swarm.best_cost,
                mean_pbest_cost=np.mean(self.swarm.pbest_cost),
                mean_neighbor_cost=self.swarm.best_cost,
                position=self.swarm.position,
                velocity=self.swarm.velocity,
            )
            self._populate_history(hist)
            # Verify stop criteria based on the relative acceptable cost ftol
            relative_measure = self.ftol * (1 + np.abs(best_cost_yet_found))
            if (
                np.abs(self.swarm.best_cost - best_cost_yet_found)
                < relative_measure
            ):
                break
            # Perform velocity and position updates
            self.swarm.velocity = self.top.compute_velocity(
                self.swarm, self.velocity_clamp, self.vh, self.bounds
            )
            self.swarm.position = self.top.compute_position(
                self.swarm, self.bounds, self.bh
            )
        # Obtain the final best_cost and the final best_position
        final_best_cost = self.swarm.best_cost.copy()
        final_best_pos = self.swarm.pbest_pos[self.swarm.pbest_cost.argmin()].copy()

        # Write report in log and return final cost and position
        self.rep.log(
            "Optimization finished | best cost: {}, best pos: {}".format(
                final_best_cost, final_best_pos
            ),
            lvl=logging.INFO,
        )

        return (final_best_cost, final_best_pos)


class GlobalBestPSO_KGPSO(SwarmOptimizer):
    def __init__(
        self,
        n_particles,
        dimensions,
        options,
        bounds=None,
        bh_strategy="periodic",
        velocity_clamp=None,
        vh_strategy="unmodified",
        center=1.00,
        ftol=-np.inf,
        init_pos=None,
    ):

        super(GlobalBestPSO_KGPSO, self).__init__(
            n_particles=n_particles,
            dimensions=dimensions,
            options=options,
            bounds=bounds,
            velocity_clamp=velocity_clamp,
            center=center,
            ftol=ftol,
            init_pos=init_pos,
        )

        # Initialize logger
        self.rep = Reporter(logger=logging.getLogger(__name__))
        # Initialize the resettable attributes
        self.reset()
        # Initialize the topology
        self.top = Star()
        self.bh = BoundaryHandler(strategy=bh_strategy)
        self.vh = VelocityHandler(strategy=vh_strategy)
        self.name = __name__
        self.clamp =None

    def calcu_dist(self,vecA,vecB):
        return np.sqrt(np.sum(np.power(vecA - vecB, 2)))

    def optimize(self, objective_func, iters, n_processes=None, **kwargs):

        global num, clusterAssment, centroids, pgklabel, temp_velocity, c1, w, c3, c2, fitkmin, pgklable
        self.rep.log("Obj. func. args: {}".format(kwargs), lvl=logging.DEBUG)
        self.rep.log(
            "Optimize for {} iters with {}".format(iters, self.options),
            lvl=logging.INFO,
        )
        # Populate memory of the handlers
        self.bh.memory = self.swarm.position
        self.vh.memory = self.swarm.position
        self.swarm.current_cost = np.zeros(self.swarm.n_particles)

        # Setup Pool of processes for parallel evaluation
        pool = None if n_processes is None else mp.Pool(n_processes)

        ksteps=self.swarm.options["ksteps"]
        kpsosteps = self.swarm.options["kpsosteps"]
        wi = self.swarm.options["wi"]
        c1i = self.swarm.options["c1i"]
        c2i = self.swarm.options["c2i"]
        c3i = self.swarm.options["c3i"]
        we = self.swarm.options["we"]
        c1e = self.swarm.options["c1e"]
        c2e = self.swarm.options["c2e"]
        c3e = self.swarm.options["c3e"]
        kpsosteps=int(iters/ksteps)
        prestep = 0
        interval = 10
        x=self.swarm.position
        self.swarm.current_cost = compute_objective_function(self.swarm, objective_func, pool=pool, **kwargs)
        self.swarm.pbest_cost = np.full(self.swarm_size[0], np.inf)
        self.swarm.pbest_pos, self.swarm.pbest_cost = compute_pbest(self.swarm)
        self.swarm.best_pos, self.swarm.best_cost = self.top.compute_gbest(self.swarm)
        temp_velocity=np.array(np.zeros(np.shape(self.swarm.velocity)))
        # Set best_cost_yet_found for ftol
        best_cost_yet_found = self.swarm.best_cost
        grad = np.mat(np.zeros((kpsosteps * ksteps, self.swarm.n_particles)))
        minsize = self.swarm.n_particles / 10
        while prestep<ksteps:
            if prestep<3:
                clusters=range(5,10)
            else:
                clusers=range(2,10)
            y_preds=[]
            for k in clusters:
                model=sc.KMeans(n_clusters=k)
                model.fit(self.swarm.position)
                pred_y=model.predict(self.swarm.position)
                y_pred=sm.calinski_harabasz_score(self.swarm.position,model.labels_)
                y_preds.append(y_pred)
                centroids=model.cluster_centers_
            kfinal=y_preds.index(max(y_preds))+clusters[0]

            model1=sc.KMeans(n_clusters=kfinal)
            model1.fit(self.swarm.position)
            pred_y1=model1.predict(self.swarm.position)
            clusterChanged=True

            while clusterChanged:
                clusterChanged=False
                pred_y2=pred_y1.tolist()
                for i in range(kfinal):
                    if pred_y2.count(i)<5:
                        kfinal=kfinal-1
                        model1=sc.KMeans(n_clusters=kfinal)
                        model1.fit(self.swarm.position)
                        pred_y1=model1.predict(self.swarm.position)
                        clusterChanged=True
                    else:
                        continue

            pgk = np.array(np.zeros((kfinal,self.swarm.dimensions)))
            for s in range(kfinal):
                fitk=[]
                for i in range(self.swarm.n_particles):
                    if pred_y1[i]==s:
                        fitk.append(float((self.swarm.current_cost[i])))
                    else:
                        continue
                fitkmin=np.min(fitk)
                for j in range(self.swarm.n_particles):
                    if self.swarm.current_cost[j]==fitkmin:
                        pgklable=j
                pgk[s]=self.swarm.position[pgklable]

            for i in self.rep.pbar(kpsosteps, self.name):
                # Compute cost for current position and personal best
                # fmt: off
                self.swarm.current_cost = compute_objective_function(self.swarm, objective_func, pool=pool, **kwargs)
                self.swarm.pbest_pos, self.swarm.pbest_cost = compute_pbest(self.swarm)
                # Set best_cost_yet_found for ftol
                best_cost_yet_found = self.swarm.best_cost
                self.swarm.best_pos, self.swarm.best_cost = self.top.compute_gbest(self.swarm)
                # fmt: on
                self.rep.hook(best_cost=self.swarm.best_cost)
                # Save to history
                hist = self.ToHistory(
                    best_cost=self.swarm.best_cost,
                    mean_pbest_cost=np.mean(self.swarm.pbest_cost),
                    mean_neighbor_cost=self.swarm.best_cost,
                    position=self.swarm.position,
                    velocity=self.swarm.velocity,
                )
                self._populate_history(hist)
                # Verify stop criteria based on the relative acceptable cost ftol
                relative_measure = self.ftol * (1 + np.abs(best_cost_yet_found))
                if (
                    np.abs(self.swarm.best_cost - best_cost_yet_found)
                    < relative_measure
                ):
                    break
                # Perform velocity and position updates

                for h in range(self.swarm.n_particles):
                    ind=int(pred_y1[h])
                    if prestep*kpsosteps+i<interval:
                        w=wi
                        c1=c1i
                        c2=c2i
                        c3=c3i
                    if prestep*kpsosteps+i>=interval:
                        w = (wi - we) * 2 * np.arctan((grad[prestep * kpsosteps + i, h] - grad[
                            prestep * kpsosteps + i - interval, h]) / interval * 1) / math.pi + we
                        c1 = (c1i - c1e) * 2 * np.arctan((grad[prestep * kpsosteps + i, h] - grad[
                            prestep * kpsosteps + i - interval, h]) / interval * 1) / math.pi + c1e
                        c2 = (c2e - c2i) * (1 - 2 * np.arctan((grad[prestep * kpsosteps + i, h] - grad[
                            prestep * kpsosteps + i - interval, h]) / interval * 1) / math.pi) + c2i
                        c3 = (c3e - c3i) * (1 - 2 * np.arctan((grad[prestep * kpsosteps + i, h] - grad[
                            prestep * kpsosteps + i - interval, h]) / interval * 1) / math.pi) + c3i
                    # Compute for cognitive and social terms
                    cognitive = (
                            c1
                            * np.random.uniform(0, 1, self.swarm_size)
                            * (self.swarm.pbest_pos[h] - self.swarm.position[h])
                    )
                    kqun=(c2*np.random.uniform(0,1,self.swarm_size)*(pgk[ind]-self.swarm.position[h]))
                    social = (
                            c3
                            * np.random.uniform(0, 1, self.swarm_size)
                            * (self.swarm.best_pos - self.swarm.position[h])
                    )
                    # Compute temp velocity (subject to clamping if possible)
                    temp_velocity[h] = (w * self.swarm.velocity[h]) + cognitive[h] + kqun[h] + social[h]
                    self.swarm.velocity[h] = temp_velocity[h]
                self.swarm.position = self.top.compute_position(
                    self.swarm, self.bounds, self.bh
                )

                self.swarm.current_cost = compute_objective_function(self.swarm, objective_func, pool=pool, **kwargs)
                for h in range(self.swarm.n_particles):
                    if self.swarm.current_cost[h] < self.swarm.pbest_cost[h]:
                        self.swarm.pbest_pos[h]=self.swarm.position[h]
                        self.swarm.pbest_cost[h]=self.swarm.current_cost[h]
                        grad[prestep * kpsosteps, h] = self.swarm.pbest_cost[h]


                for s in range(kfinal):
                    fitk=[]
                    for i in range(self.swarm.n_particles):
                        if pred_y1[i]==s:
                            fitk.append(float(self.swarm.current_cost[i]))
                        else:
                            continue
                    fitkmin=np.min(fitk)
                    for j in range(self.swarm.n_particles):
                        if self.swarm.current_cost[j]== fitkmin:
                            pgklable=j
                    pgk[s]=self.swarm.position[pgklable]
                    if np.min(self.swarm.current_cost)<self.swarm.best_cost:
                        self.swarm.best_pos=self.swarm.position[np.argmin(self.swarm.current_cost)]
                        self.swarm.best_cost=np.min(self.swarm.current_cost)
                    final_best_cost = self.swarm.best_cost.copy()
                    final_best_pos = self.swarm.pbest_pos[self.swarm.pbest_cost.argmin()].copy()
            prestep+=1
        # Obtain the final best_cost and the final best_position

        final_best_cost = self.swarm.best_cost.copy()
        final_best_pos = self.swarm.pbest_pos[self.swarm.pbest_cost.argmin()].copy()
        # Write report in log and return final cost and position
        self.rep.log(
            "Optimization finished | best cost: {}, best pos: {}".format(
                final_best_cost, final_best_pos
            ),
            lvl=logging.INFO,
        )
        return (final_best_cost,final_best_pos)


class GlobalBestPSO_KGPSO1(SwarmOptimizer):
    def __init__(
        self,
        n_particles,
        dimensions,
        options,
        bounds=100,
        bh_strategy="periodic",
        velocity_clamp=None,
        vh_strategy="unmodified",
        center=1.00,
        ftol=-np.inf,
        init_pos=None,
    ):

        super(GlobalBestPSO_KGPSO1, self).__init__(
            n_particles=n_particles,
            dimensions=dimensions,
            options=options,
            bounds=bounds,
            velocity_clamp=velocity_clamp,
            center=center,
            ftol=ftol,
            init_pos=init_pos,
        )

        # Initialize logger
        self.rep = Reporter(logger=logging.getLogger(__name__))
        # Initialize the resettable attributes
        self.reset()
        # Initialize the topology
        self.top = Star()
        self.bh = BoundaryHandler(strategy=bh_strategy)
        self.vh = VelocityHandler(strategy=vh_strategy)
        self.name = __name__
        self.clamp =None

    def calcu_dist(self,vecA,vecB):
        return np.sqrt(np.sum(np.power(vecA - vecB, 2)))

    def optimize(self, objective_func, iters, n_processes=None, **kwargs):

        global num, clusterAssment, centroids, pgklabel, temp_velocity, c1, w, c3, c2, fitkmin, pgklable
        self.rep.log("Obj. func. args: {}".format(kwargs), lvl=logging.DEBUG)
        self.rep.log(
            "Optimize for {} iters with {}".format(iters, self.options),
            lvl=logging.INFO,
        )
        # Populate memory of the handlers
        self.bh.memory = self.swarm.position
        self.vh.memory = self.swarm.position
        self.swarm.current_cost = np.zeros(self.swarm.n_particles)
        # Setup Pool of processes for parallel evaluation
        pool = None if n_processes is None else mp.Pool(n_processes)

        ksteps=self.swarm.options["ksteps"]
        kpsosteps = self.swarm.options["kpsosteps"]
        wi = self.swarm.options["wi"]
        c1i = self.swarm.options["c1i"]
        c2i = self.swarm.options["c2i"]
        c3i = self.swarm.options["c3i"]
        we = self.swarm.options["we"]
        c1e = self.swarm.options["c1e"]
        c2e = self.swarm.options["c2e"]
        c3e = self.swarm.options["c3e"]
        kpsosteps=int(iters/ksteps)
        prestep = 0
        interval = 10
        x=self.swarm.position
        self.swarm.current_cost = compute_objective_function(self.swarm, objective_func, pool=pool, **kwargs)
        self.swarm.pbest_cost = np.full(self.swarm_size[0], np.inf)
        self.swarm.pbest_pos, self.swarm.pbest_cost = compute_pbest(self.swarm)
        self.swarm.best_pos, self.swarm.best_cost = self.top.compute_gbest(self.swarm)
        temp_velocity=np.array(np.zeros(np.shape(self.swarm.velocity)))
        # Set best_cost_yet_found for ftol
        best_cost_yet_found = self.swarm.best_cost
        grad = np.mat(np.zeros((kpsosteps * ksteps, self.swarm.n_particles)))
        minsize = self.swarm.n_particles / 10
        while prestep<ksteps:
            k=10
            while k>=1:
                n=np.shape(self.swarm.position)[1]
                centroids=np.mat(np.zeros((k,n)))
                for j in range(n):
                    minJ=min(x[:,j])
                    rangeJ=float(max(np.array(x)[:,j]-minJ))
                    centroids[:,j]=minJ+rangeJ*np.random.rand(k,1)
                m=np.shape(self.swarm.position)[0]
                clusterAssment=np.mat(np.zeros((m,2)))
                clusterChanged=True
                while clusterChanged:
                    clusterChanged=False
                    for i in range(m):
                        minDist=np.inf
                        minIndex=-1
                        for j in range(k):
                            distJI=self.calcu_dist(centroids[j,:],self.swarm.position[i,:])
                            if distJI<minDist:
                                minDist=distJI
                                minIndex=j
                        if clusterAssment[i,0]!=minIndex:
                            clusterChanged=True
                            clusterAssment[i,:]=minIndex,minDist ** 2
                for cen in range(k):
                    num=0
                    for j in range(self.swarm.n_particles):
                        if clusterAssment[j,0]==cen:
                            num=num+1
                    if num>=minsize:
                        continue
                    if num<minsize:
                        k=k-1
                        break
                if num >=minsize:
                    break

            for cent in range(k):
                ptsInClust=x[np.nonzero(clusterAssment[:,0].A == cent)[0]]
                centroids[cent,:] = np.mean(ptsInClust,axis=0)
            kfinal=k


            Index = np.mat(np.zeros((self.swarm.n_particles,1)))
            for i in range(self.swarm.n_particles):
                Index[i]=i
            clustinfo=clusterAssment[:,0]
            pgk = np.array(np.zeros((kfinal,self.swarm.dimensions)))
            for s in range(kfinal):
                fitk=[]
                for i in range(self.swarm.n_particles):
                    if clustinfo[i]==s:
                        fitk.append(float((self.swarm.current_cost[i])))
                    else:
                        continue
                fitkmin=np.min(fitk)
                for j in range(self.swarm.n_particles):
                    if self.swarm.current_cost[j]==fitkmin:
                        pgklable=j
                pgk[s]=self.swarm.position[pgklable]

            for i in self.rep.pbar(kpsosteps, self.name):
                # Compute cost for current position and personal best
                # fmt: off
                self.swarm.current_cost = compute_objective_function(self.swarm, objective_func, pool=pool, **kwargs)

                self.swarm.pbest_pos, self.swarm.pbest_cost = compute_pbest(self.swarm)
                # Set best_cost_yet_found for ftol
                best_cost_yet_found = self.swarm.best_cost
                self.swarm.best_pos, self.swarm.best_cost = self.top.compute_gbest(self.swarm)
                # fmt: on
                self.rep.hook(best_cost=self.swarm.best_cost)
                # Save to history
                hist = self.ToHistory(
                    best_cost=self.swarm.best_cost,
                    mean_pbest_cost=np.mean(self.swarm.pbest_cost),
                    mean_neighbor_cost=self.swarm.best_cost,
                    position=self.swarm.position,
                    velocity=self.swarm.velocity,
                )
                self._populate_history(hist)
                # Verify stop criteria based on the relative acceptable cost ftol
                relative_measure = self.ftol * (1 + np.abs(best_cost_yet_found))
                if (
                    np.abs(self.swarm.best_cost - best_cost_yet_found)
                    < relative_measure
                ):
                    break
                # Perform velocity and position updates

                for h in range(self.swarm.n_particles):
                    ind=int(clustinfo[h])
                    if prestep*kpsosteps+i<interval:
                        w=wi
                        c1=c1i
                        c2=c2i
                        c3=c3i
                    if prestep*kpsosteps+i>=interval:
                        w = (wi - we) * 2 * np.arctan((grad[prestep * kpsosteps + i, h] - grad[
                            prestep * kpsosteps + i - interval, h]) / interval * 1) / math.pi + we
                        c1 = (c1i - c1e) * 2 * np.arctan((grad[prestep * kpsosteps + i, h] - grad[
                            prestep * kpsosteps + i - interval, h]) / interval * 1) / math.pi + c1e
                        c2 = (c2e - c2i) * (1 - 2 * np.arctan((grad[prestep * kpsosteps + i, h] - grad[
                            prestep * kpsosteps + i - interval, h]) / interval * 1) / math.pi) + c2i
                        c3 = (c3e - c3i) * (1 - 2 * np.arctan((grad[prestep * kpsosteps + i, h] - grad[
                            prestep * kpsosteps + i - interval, h]) / interval * 1) / math.pi) + c3i

                    cognitive = (
                            c1
                            * np.random.uniform(0, 1, self.swarm_size)
                            * (self.swarm.pbest_pos[h] - self.swarm.position[h])
                    )
                    kqun=(c2*np.random.uniform(0,1,self.swarm_size)*(pgk[ind]-self.swarm.position[h]))
                    social = (
                            c3
                            * np.random.uniform(0, 1, self.swarm_size)
                            * (self.swarm.best_pos - self.swarm.position[h])
                    )

                    temp_velocity[h] = (w * self.swarm.velocity[h]) + cognitive[h] + kqun[h] + social[h]
                    self.swarm.velocity[h] = temp_velocity[h]
                self.swarm.position = self.top.compute_position(
                    self.swarm, self.bounds, self.bh
                )
                self.swarm.current_cost = compute_objective_function(self.swarm, objective_func, pool=pool, **kwargs)

                for h in range(self.swarm.n_particles):
                    if self.swarm.current_cost[h] < self.swarm.pbest_cost[h]:
                        self.swarm.pbest_pos[h]=self.swarm.position[h]
                        self.swarm.pbest_cost[h]=self.swarm.current_cost[h]
                        grad[prestep * kpsosteps, h] = self.swarm.pbest_cost[h]


                for s in range(kfinal):
                    fitk=[]
                    for i in range(self.swarm.n_particles):
                        if clustinfo[i]==s:
                            fitk.append(float(self.swarm.current_cost[i]))
                        else:
                            continue
                    fitkmin=np.min(fitk)
                    for j in range(self.swarm.n_particles):
                        if self.swarm.current_cost[j]== fitkmin:
                            pgklable=j
                    pgk[s]=self.swarm.position[pgklable]
                    if np.min(self.swarm.current_cost)<self.swarm.best_cost:
                        self.swarm.best_pos=self.swarm.position[np.argmin(self.swarm.current_cost)]
                        self.swarm.best_cost=np.min(self.swarm.current_cost)
                    final_best_cost = self.swarm.best_cost.copy()
                    final_best_pos = self.swarm.pbest_pos[self.swarm.pbest_cost.argmin()].copy()

            prestep+=1
        # Obtain the final best_cost and the final best_position

        final_best_cost = self.swarm.best_cost.copy()
        final_best_pos = self.swarm.pbest_pos[self.swarm.pbest_cost.argmin()].copy()
        # Write report in log and return final cost and position
        self.rep.log(
            "Optimization finished | best cost: {}, best pos: {}".format(
                final_best_cost, final_best_pos
            ),
            lvl=logging.INFO,
        )
        return (final_best_cost,final_best_pos)












