import pyswarms as ps
import numpy as np
from pyswarms.utils.functions import single_obj as fx
from pyswarms.utils.plotters import plot_cost_history
import matplotlib.pyplot as plt
from pyswarms.utils.plotters.formatters import Mesher
from pyswarms.utils.plotters.formatters import Designer
from pyswarms.utils.plotters import plot_contour, plot_surface
import os

particle=100
iterss=20000
runs=1
bound=5.12
function=fx.rastrigin
dimension1=[100]
# dimension1=[10,30,50,100]

for r in range(len(dimension1)):
    max_bound = bound * np.ones(dimension1[r])
    min_bound = - max_bound
    bounds = (min_bound, max_bound)
    for i in range(runs):

            options = {'c1i': 2.23, 'c1e': 1.13, 'c2i': 0.93, 'c2e': 1.75, 'c3i': 0.6, 'c3e': 1.3, 'wi': 0.8,
                       'we': 0.35, 'kmax': 10, 'kpsosteps': 100, 'ksteps': 200}
            optimizer = ps.single.global_best.GlobalBestPSO_KGPSO(n_particles=particle, dimensions=dimension1[r],
                                                                    options=options, bounds=bounds)
            optimizer.optimize(function, iters=iterss)  # K-Means using CH index

            # options = {'c1i': 2.23, 'c1e': 1.13, 'c2i': 0.93, 'c2e': 1.75, 'c3i': 0.6, 'c3e': 1.3, 'wi': 0.8,
            #            'we': 0.35, 'kmax': 10, 'kpsosteps': 100, 'ksteps': 200}
            # optimizer = ps.single.global_best.GlobalBestPSO_KGPSO1(n_particles=particle, dimensions=dimension1[r],
            #                                                         options=options, bounds=bounds)
            # optimizer.optimize(function, iters=iterss)  # K-Means without using CH index
